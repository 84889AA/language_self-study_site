package com.uep.wap.controller;

//import com.uep.wap.dto.AnalyticalDashboardDTO;
import com.uep.wap.model.AnalyticalDashboard;
import com.uep.wap.service.AnalyticalDashboardsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
//@RequestMapping(path = "/api")
public class AnalyticalDashboardController {

    @Autowired
    private AnalyticalDashboardsService analyticalDashboardsService;

    @PostMapping(path = "/addAnalyticalDashboard")
    public AnalyticalDashboard postDetails(@RequestBody AnalyticalDashboard analyticalDashboard){
        return analyticalDashboardsService.saveDetails(analyticalDashboard);
    }

   /*
    private final AnalyticalDashboardsService analyticalDashboardsService;

    public AnalyticalDashboardController(AnalyticalDashboardsService analyticalDashboardsService) {
        this.analyticalDashboardsService = analyticalDashboardsService;
    }

    @GetMapping(path = "/analyticalDashboards")
    public Iterable<AnalyticalDashboard> getAllAnalyticalDashboards(){
        return analyticalDashboardsService.getAllAnalyticalDashboards();
    }

    @PostMapping(path = "/analyticalDashboards")
    public String addAnalyticalDashboards(@RequestBody AnalyticalDashboardDTO analyticalDashboardDTO){
        analyticalDashboardsService.addAnalyticalDashboard(analyticalDashboardDTO);
        return "AnalyticalDashboards added!";
    }
    */
}
