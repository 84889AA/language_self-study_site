/*package com.uep.wap.service;

import com.uep.wap.model.LevelOfAdvancement;
import com.uep.wap.repository.LevelOfAdvancementRepository;
import com.uep.wap.dto.LevelOfAdvancementDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class LevelOfAdvancementsService {

    @Autowired
    private LevelOfAdvancementRepository levelOfAdvancementRepository;

    public void addLevelOfAdvancement(LevelOfAdvancementDTO levelOfAdvancementDTO) {
        LevelOfAdvancement levelOfAdvancement = new LevelOfAdvancement();
        levelOfAdvancement.setName(levelOfAdvancementDTO.getName());
        levelOfAdvancement.setLanguage(levelOfAdvancementDTO.getLanguage());
        levelOfAdvancementRepository.save(levelOfAdvancement);
        System.out.println("LevelOfAdvancements added!");
    }

    public Iterable<LevelOfAdvancement> getAllLevelOfAdvancements() {
        return levelOfAdvancementRepository.findAll();
    }

}*/




