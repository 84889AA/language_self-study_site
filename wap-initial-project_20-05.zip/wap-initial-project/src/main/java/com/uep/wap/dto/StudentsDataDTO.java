/*package com.uep.wap.dto;

import java.util.List;

public class StudentsDataDTO {

    private String people;

    public String getPeople() {
        return people;
    }

    public void setPeople(String people) {
        this.people = people;
    }
}*/