/*package com.uep.wap.controller;

import com.uep.wap.dto.CourseDTO;
import com.uep.wap.model.Course;
import com.uep.wap.service.CoursesService;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping(path = "/api")
public class CourseController {

    private final CoursesService coursesService;

    public CourseController(CoursesService coursesService) {
        this.coursesService = coursesService;
    }

    @GetMapping(path = "/courses")
    public Iterable<Course> getAllCourses(){
        return coursesService.getAllCourses();
    }

    @PostMapping(path = "/courses")
    public String addCourses(@RequestBody CourseDTO courseDTO){
        coursesService.addCourse(courseDTO);
        return "Courses added!";
    }

}
*/