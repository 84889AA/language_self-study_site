/*package com.uep.wap.controller;

import com.uep.wap.dto.LanguageDTO;
import com.uep.wap.model.Language;
import com.uep.wap.service.LanguagesService;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping(path = "/api")
public class LanguageController {

    private final LanguagesService languagesService;

    public LanguageController(LanguagesService languagesService) {
        this.languagesService = languagesService;
    }

    @GetMapping(path = "/languages")
    public Iterable<Language> getAllLanguages(){
        return languagesService.getAllLanguages();
    }

    @PostMapping(path = "/languages")
    public String addLanguages(@RequestBody LanguageDTO languageDTO){
        languagesService.addLanguage(languageDTO);
        return "Languages added!";
    }

}
*/