/*package com.uep.wap.model;

import javax.persistence.*;

@Entity
public class AnalyticalDashboard {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int dashboard_id;
    private String role;
    private Object statistics;

    @ManyToOne
    @JoinColumn(name = "user_id")
    private User user;

    public int getDashboard_id() {
        return dashboard_id;
    }

    public void setDashboard_id(int dashboard_id) {
        this.dashboard_id = dashboard_id;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public Object getStatistics() {
        return statistics;
    }

    public void setStatistics(Object statistics) {
        this.statistics = statistics;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }
}
*/
package com.uep.wap.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Entity
@Data
@Table(name="AnalyticalDashboardDB")
@NoArgsConstructor
@AllArgsConstructor

public class AnalyticalDashboard {

    @Id
    @Column(name = "Dashboard_id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer dashboard_id;

    @Column(name="role")
    private String role;

    @Column(name="statistics")
    private String statistics;

}

