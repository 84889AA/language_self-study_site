/*package com.uep.wap.service;

import com.uep.wap.model.Course;
import com.uep.wap.repository.CourseRepository;
import com.uep.wap.dto.CourseDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CoursesService {

    @Autowired
    private CourseRepository courseRepository;

    public void addCourse(CourseDTO courseDTO) {
        Course course = new Course();
        course.setId(courseDTO.getId());
        course.setName(courseDTO.getName());
        course.setLanguage(courseDTO.getLanguage());
        course.setTopic(courseDTO.getTopic());
        course.setUser_id(courseDTO.getUser_id());
        course.setRole(courseDTO.getRole());
        course.setLanguage(courseDTO.getLanguage());
        course.setUsers(courseDTO.getUsers());
        courseRepository.save(course);
        System.out.println("Courses added!");
    }

    public Iterable<Course> getAllCourses() {
        return courseRepository.findAll();
    }

}
*/



