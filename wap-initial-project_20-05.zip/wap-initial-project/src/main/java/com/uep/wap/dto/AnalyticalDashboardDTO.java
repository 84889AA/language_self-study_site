/*package com.uep.wap.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Entity
@Data
@Table(name="AnalyticalDashboardDB")
@NoArgsConstructor
@AllArgsConstructor

public class AnalyticalDashboardDTO {

    @Id
    @Column(name = "Dashboard_id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer dashboard_id;

    @Column(name="role")
    private String role;

    @Column(name="statistics")
    private String statistics;

}*/
