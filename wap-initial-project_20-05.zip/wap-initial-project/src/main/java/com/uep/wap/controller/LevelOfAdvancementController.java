/*package com.uep.wap.controller;

import com.uep.wap.dto.LevelOfAdvancementDTO;
import com.uep.wap.model.LevelOfAdvancement;
import com.uep.wap.service.LevelOfAdvancementsService;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping(path = "/api")
public class LevelOfAdvancementController {

    private final LevelOfAdvancementsService levelOfAdvancementsService;

    public LevelOfAdvancementController(LevelOfAdvancementsService levelOfAdvancementsService) {
        this.levelOfAdvancementsService = levelOfAdvancementsService;
    }

    @GetMapping(path = "/levelOfAdvancements")
    public Iterable<LevelOfAdvancement> getAllLevelOfAdvancements(){
        return levelOfAdvancementsService.getAllLevelOfAdvancements();
    }

    @PostMapping(path = "/levelOfAdvancements")
    public String addLevelOfAdvancements(@RequestBody LevelOfAdvancementDTO levelOfAdvancementDTO){
        levelOfAdvancementsService.addLevelOfAdvancement(levelOfAdvancementDTO);
        return "LevelOfAdvancements added!";
    }

}*/
