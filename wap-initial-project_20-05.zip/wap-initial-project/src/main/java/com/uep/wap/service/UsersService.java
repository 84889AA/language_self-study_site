/*package com.uep.wap.service;

import com.uep.wap.model.User;
import com.uep.wap.repository.UserRepository;
import com.uep.wap.dto.UserDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UsersService {

    @Autowired
    private UserRepository userRepository;

    public void addUser(UserDTO userDTO) {
        User user = new User();
        user.setName(userDTO.getName());
        user.setSurname(userDTO.getSurname());
        user.setId(userDTO.getId());
        user.setLogin(userDTO.getLogin());
        user.setPassword(userDTO.getPassword());
        user.setEmail(userDTO.getEmail());
        user.setRole(userDTO.getRole());
        user.setCountry(userDTO.getCountry());
        user.setMaterials2(userDTO.getMaterials2());
        user.setCourses(userDTO.getCourses());
        user.setLanguages(userDTO.getLanguages());
        user.setAnalytic_dashboards(userDTO.getAnalitical_dashboards());

        user.setPoints(userDTO.getPoints());
        userRepository.save(user);
        System.out.println("Users added!");
    }

    public Iterable<User> getAllUsers() {
        return userRepository.findAll();
    }

}*/




