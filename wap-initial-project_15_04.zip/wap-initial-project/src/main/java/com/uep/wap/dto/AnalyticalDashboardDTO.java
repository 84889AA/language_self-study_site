package com.uep.wap.dto;

public class AnalyticalDashboardDTO {

    private String role;
    private Integer dashboard_id;
    private Object statistics;

    public Integer getDashboard_id() {
        return dashboard_id;
    }

    public void setDashboard_id(Integer dashboard_id) {
        this.dashboard_id = dashboard_id;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public Object getStatistics() {
        return statistics;
    }

    public void setStatistics(Object statistics) {
        this.statistics = statistics;
    }
}
