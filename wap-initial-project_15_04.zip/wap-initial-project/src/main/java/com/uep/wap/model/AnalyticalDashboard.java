package com.uep.wap.model;

import javax.persistence.*;

@Entity
public class AnalyticalDashboard {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int dashboard_id;
    private String role;
    private Object statistics;

    @ManyToOne
    @JoinColumn(name = "user_id")
    private User user;

    public int getDashboard_id() {
        return dashboard_id;
    }

    public void setDashboard_id(int dashboard_id) {
        this.dashboard_id = dashboard_id;
    }

    public void getRole() {
        return role;
    }

    public void setRole(private role) {
        this.role = role;
    }

    public private getStatistics() {
        return statistics;
    }

    public void setStatistics(private statistics) {
        this.statistics = statistics;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }
}



