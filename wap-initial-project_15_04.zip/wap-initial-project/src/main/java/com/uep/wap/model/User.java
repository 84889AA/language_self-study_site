package com.uep.wap.model;

import javax.persistence.*;
import java.util.List;

@Entity
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)

    private int id;
    private String name;
    private String surname;
    private String login;
    private String password;
    private String email;
    private String role;
    private String country;

    @OneToMany(mappedBy = "user", cascade = CascadeType.ALL)
    private List<Material> materials2;

    @OneToMany(mappedBy = "author", cascade = CascadeType.ALL)
    private List<Course> courses;

    @OneToMany(mappedBy = "author", cascade = CascadeType.ALL)
    private List<Language> languages;

    @OneToMany(mappedBy = "author", cascade = CascadeType.ALL)
    private List<AnalyticalDashboard> analytic_dashboards;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public List<Material> getMaterials2() {
        return materials2;
    }

    public void setMaterials2(List<Material> materials2) {
        this.materials2 = materials2;
    }

    public List<Course> getCourses() {
        return courses;
    }

    public void setCourses(List<Course> courses) {
        this.courses = courses;
    }

    public List<Language> getLanguages() {
        return languages;
    }

    public void setLanguages(List<Language> languages) {
        this.languages = languages;
    }

    public List<AnalyticalDashboard> getAnalytic_dashboards() {
        return analytic_dashboards;
    }

    public void setAnalytic_dashboards(List<AnalyticalDashboard> analytic_dashboards) {
        this.analytic_dashboards = analytic_dashboards;
    }
}



