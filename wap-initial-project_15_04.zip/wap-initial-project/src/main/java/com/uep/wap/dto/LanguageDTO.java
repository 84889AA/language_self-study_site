package com.uep.wap.dto;

import com.uep.wap.model.Course;
import com.uep.wap.model.LevelOfAdvancement;
import com.uep.wap.model.User;

import java.util.List;

public class LanguageDTO {

    private String name;
    private Course course;
    private List<LevelOfAdvancement> level_of_advancement ;
    private User user;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Course getCourse() {
        return course;
    }

    public void setCourse(Course course) {
        this.course = course;
    }

    public List<LevelOfAdvancement> getLevel_of_advancement() {
        return level_of_advancement;
    }

    public void setLevel_of_advancement(List<LevelOfAdvancement> level_of_advancement) {
        this.level_of_advancement = level_of_advancement;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }
}
