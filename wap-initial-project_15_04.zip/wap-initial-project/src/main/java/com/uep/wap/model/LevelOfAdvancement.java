package com.uep.wap.model;

import javax.persistence.*;

@Entity
public class LevelOfAdvancement {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private String name;


    @ManyToOne
    @JoinColumn(name = "language_id")
    private Language language;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Language getLanguage() {
        return language;
    }

    public void setLanguage(Language language) {
        this.language = language;
    }
}


