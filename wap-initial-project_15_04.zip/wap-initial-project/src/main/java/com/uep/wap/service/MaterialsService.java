package com.uep.wap.service;

import com.uep.wap.model.Material;
import com.uep.wap.model.User;
import com.uep.wap.repository.MaterialRepository;
import com.uep.wap.dto.MaterialDTO;
import com.uep.wap.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MaterialsService {

    @Autowired
    private MaterialRepository materialRepository;
    @Autowired
    private UserRepository userRepository;

    public void addMaterial(MaterialDTO materialDTO) {
        Material material = new Material();
        material.setId(materialDTO.getId());
//        material.setUser_id(materialDTO.getUser_id());
        material.setRole(materialDTO.getRole());
        material.setCourse(materialDTO.getCourse());
        User user = userRepository.findById(materialDTO.getUser_id()).get();
        material.setUser(user);
        materialRepository.save(material);
        System.out.println("Materials added!");
    }

    public Iterable<Material> getAllMaterials() {
        return materialRepository.findAll();
    }

}




