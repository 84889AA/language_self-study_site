package com.uep.wap.service;

import com.uep.wap.model.Course;
import com.uep.wap.repository.CourseRepository;
import com.uep.wap.dto.CourseDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CoursesService {

    @Autowired
    private CourseRepository courseRepository;

    public void addCourse(CourseDTO courseDTO) {
        Course course = new Course();
        course.setName(courseDTO.getName());
        course.setPoints(courseDTO.getPoints());
        courseRepository.save(course);
        System.out.println("Courses added!");
    }

    public Iterable<Course> getAllCourses() {
        return courseRepository.findAll();
    }

}




