package com.uep.wap.model;

import javax.persistence.*;

@Entity
public class Analytical_dashboard {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int dashboard_id;
    private String role;
    private Object statistics;

    @ManyToOne
    @JoinColumn(name = "user_id")
    private User user;

    public int getDashboard_id() {
        return dashboard_id;
    }

    public void setDashboard_id(int dashboard_id) {
        this.dashboard_id = dashboard_id;
    }

    public private getString() {
        return String;
    }

    public void setString(private String) {
        String = String;
    }

    public private getObject() {
        return Object;
    }

    public void setObject(private Object) {
        this.Object = Object;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }
}



