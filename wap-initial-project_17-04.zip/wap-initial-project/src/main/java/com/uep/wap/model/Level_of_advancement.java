package com.uep.wap.model;

import javax.persistence.*;

@Entity
public class Level_of_advancement {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private String name;
    private String language;

    @ManyToOne
    @JoinColumn(name = "language_id")
    private Language language;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLanguage() {
        return language;
    }

    public void setLanguage(Language language) {
        this.language = language;
    }

    public void setLanguage(String language) {
        this.language = language;
    }
}


