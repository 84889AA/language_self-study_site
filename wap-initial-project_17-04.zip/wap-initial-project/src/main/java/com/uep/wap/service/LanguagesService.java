package com.uep.wap.service;

import com.uep.wap.dto.LanguageDTO;
import com.uep.wap.model.Language;
import com.uep.wap.repository.LanguageRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class LanguagesService {

    @Autowired
    private LanguageRepository languageRepository;

    public void addLanguage(LanguageDTO languageDTO) {
        Language language = new Language();
        language.setName(languageDTO.getName());
        language.setPoints(languageDTO.getPoints());
        languageRepository.save(language);
        System.out.println("Languages added!");
    }

    public Iterable<Language> getAllLanguages() {
        return languageRepository.findAll();
    }

}




