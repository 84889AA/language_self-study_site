package com.uep.wap.controller;

import com.uep.wap.model.User;
import com.uep.wap.service.UsersService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class UserController {

    private UsersService usersService;

    @PostMapping(path = "/addUser")
    public User postDetailsUser(@RequestBody User user){
        return usersService.saveDetails(user);
    }

    @GetMapping(path="/getUsers")
    public List<User> getDetailsUsers(){
        return usersService.getAllDetails();
    }

    @GetMapping("/getUserById/{userId}")
    public User getDetailsUserById(@PathVariable int userId){
        return usersService.getDetailsById(userId);
    }

    @DeleteMapping("/deleteUser/{userId}")
    public String deleteUser(@PathVariable int userId){
        return usersService.deleteUser(userId);
    }
}