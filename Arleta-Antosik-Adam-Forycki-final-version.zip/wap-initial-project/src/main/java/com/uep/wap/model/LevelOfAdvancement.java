package com.uep.wap.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Entity
@Data
@Table(name="LevelOfAdvancement")
@NoArgsConstructor
@AllArgsConstructor
public class LevelOfAdvancement {

    @Id
    @Column(name="nameOfLevel")
    private String nameOfLevel;

    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "fk_languageName", referencedColumnName = "languageName")
    private Language language;
}


