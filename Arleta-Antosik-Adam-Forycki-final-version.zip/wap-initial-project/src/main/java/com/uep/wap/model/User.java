package com.uep.wap.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.List;

@Entity
@Data
@Table(name="User")
@NoArgsConstructor
@AllArgsConstructor

public class User {

    @Id
    @Column(name="UserId")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer userId;

    @Column(name="name")
    private String name;

    @Column(name="surname")
    private String surname;

    @Column(name="login")
    private String login;

    @Column(name="password")
    private String password;

    @Column(name="email")
    private String email;

    @Column(name="role")
    private String role;

    @Column(name="country")
    private String country;

    @OneToMany(mappedBy="user", cascade = CascadeType.ALL)
    private List<AnalyticalDashboard> analyticalDashboard;

    @OneToMany(mappedBy="user", cascade = CascadeType.ALL)
    private List<Material> material;

    @OneToMany(mappedBy="user", cascade = CascadeType.ALL)
    private List<Course> course;

    @OneToMany(mappedBy="user", cascade = CascadeType.ALL)
    private List<Language> language;

}



