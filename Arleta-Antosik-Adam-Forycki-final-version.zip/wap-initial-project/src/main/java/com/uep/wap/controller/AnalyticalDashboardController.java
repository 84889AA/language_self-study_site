package com.uep.wap.controller;

import com.uep.wap.model.AnalyticalDashboard;
import com.uep.wap.service.AnalyticalDashboardsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.ui.Model;

import java.util.List;

@Controller
//@RequestMapping(path = "/api")
public class AnalyticalDashboardController {

    @Autowired
    private AnalyticalDashboardsService analyticalDashboardsService;

    @PostMapping(path = "/addAnalyticalDashboard")
    public AnalyticalDashboard postDetailsAnalyticalDashboard(@RequestBody AnalyticalDashboard analyticalDashboard){
        return analyticalDashboardsService.saveDetails(analyticalDashboard);
    }

    //html
   /*@GetMapping(path="/getAnalyticalDashboardsView")
    public String getDetailsAnalyticalDashboards(Model model){
        model.addAttribute("attributename");
        List<AnalyticalDashboard> dashboards = analyticalDashboardsService.getAllDetails();
        model.addAttribute("dashboards", dashboards);
        return "AnalyticalDashboard";
    }*/

    /*@GetMapping(path="/api")
    public String getDetailsAnalyticalDashboards(Model model){
        model.addAttribute("attributename");
        List<AnalyticalDashboard> dashboards = analyticalDashboardsService.getAllDetails();
        model.addAttribute("dashboards", dashboards);
        return "AnalyticalDashboard";
    }*/


    //strony

    @GetMapping("/")
    public String stronaglowna() {
        return "main"; // This corresponds to francuski/pogoda.html in the templates directory
    }

    @GetMapping("/francuski/pogoda")
    public String francuskiPogoda() {
        return "francuski-pogoda"; // This corresponds to francuski/pogoda.html in the templates directory
    }

    @GetMapping("/francuski/pogoda/2")
    public String francuskiPogoda2() {
        return "francuski-pogoda-dwa"; // This corresponds to francuski/pogoda.html in the templates directory
    }

    @GetMapping("/francuski/pogoda/3")
    public String francuskiPogoda3() {
        return "francuski-pogoda-trzy"; // This corresponds to francuski/pogoda.html in the templates directory
    }

    @GetMapping("/francuski/pogoda/4")
    public String francuskiPogoda4() {
        return "francuski-pogoda-cztery"; // This corresponds to francuski/pogoda.html in the templates directory
    }

    @GetMapping("/analyticaldashboards")
    public String getAllDashboards(Model model) {
        model.addAttribute("attributename");
        List<AnalyticalDashboard> dashboards = analyticalDashboardsService.getAllDetails();
        model.addAttribute("dashboards", dashboards);
        return "AnalyticalDashboard";
    }

    //json
    @GetMapping(path="/getAnalyticalDashboards")
    public List<AnalyticalDashboard> getDetailsAnalyticalDashboards(){
        return analyticalDashboardsService.getAllDetails();
    }

    @GetMapping("/getAnalyticalDashboardById/{dashboard_id}")
    public AnalyticalDashboard getDetailsAnalyticalDashboardById(@PathVariable int dashboard_id){
        return analyticalDashboardsService.getDetailsById(dashboard_id);
    }

    @PutMapping("/updateAnalyticalDashboard")
    public AnalyticalDashboard updateDetailsAnalyticalDashboard(@RequestBody AnalyticalDashboard analyticalDashboard){
        return analyticalDashboardsService.updateDetails(analyticalDashboard);
    }

    @DeleteMapping("/deleteAnalyticalDashboard/{dashboard_id}")
    public String deleteAnalyticalDashboard(@PathVariable int dashboard_id){
        return analyticalDashboardsService.deleteAnalyticalDashboard(dashboard_id);
    }
}
