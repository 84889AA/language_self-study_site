package com.uep.wap.service;

import com.uep.wap.model.User;
import com.uep.wap.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UsersService {

    @Autowired
    private UserRepository userRepository;

    public User saveDetails(User user){
        return userRepository.save(user);
    }

    public List<User> getAllDetails(){
        return userRepository.findAll();
    }

    public User getDetailsById(int userId){
        return userRepository.findById(userId).orElse(null);
    }

    public User updateDetails(User user){
        User updateUser = userRepository.findById(user.getUserId()).orElse(null);
        if(updateUser != null){
            updateUser.setName(user.getName());
            updateUser.setSurname(user.getSurname());
            updateUser.setLogin(user.getLogin());
            updateUser.setPassword(user.getPassword());
            updateUser.setEmail(user.getEmail());
            updateUser.setRole(user.getRole());
            updateUser.setCountry(user.getCountry());
            userRepository.save(updateUser);
            return updateUser;
        }
        return null;
    }

    public String deleteUser(int userId){
        if(userRepository.existsById(userId)){
            userRepository.deleteById(userId);
            return "deleted"+userId;
        }else{
            return "not found";
        }
    }
}




