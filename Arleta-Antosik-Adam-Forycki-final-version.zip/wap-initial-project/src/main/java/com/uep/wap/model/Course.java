package com.uep.wap.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.List;

@Entity
@Data
@Table(name="Course")
@NoArgsConstructor
@AllArgsConstructor
public class Course {

    @Id
    @Column(name="courseId")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int courseId;

    @Column(name="name")
    private String name;

    @Column(name="topic")
    private String topic;

    @OneToMany(mappedBy = "course",cascade = CascadeType.ALL)
    private List<Material> material;

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "fk_languageName")
    private Language language;

    @ManyToOne
    @JoinColumn(name = "fk_user_id",referencedColumnName = "userId")
    private User user;
}



