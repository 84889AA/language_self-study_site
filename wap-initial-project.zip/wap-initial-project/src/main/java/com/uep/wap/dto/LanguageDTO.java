package com.uep.wap.dto;

import com.uep.wap.model.Course;
import com.uep.wap.model.LevelOfAdvancement;
import com.uep.wap.model.User;

import java.util.List;

public class LanguageDTO {

    private String name;
    private String course;
    private String level_of_advancement ;
    private String user;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCourse() {
        return course;
    }

    public void setCourse(String course) {
        this.course = course;
    }

    public String getLevel_of_advancement() {
        return level_of_advancement;
    }

    public void setLevel_of_advancement(String level_of_advancement) {
        this.level_of_advancement = level_of_advancement;
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }
}
