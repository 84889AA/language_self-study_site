package com.uep.wap.dto;

public class AnalyticalDashboardDTO {

    private String role;
    private Integer dashboard_id;
    private String statistics;

    public Integer getDashboard_id() {
        return dashboard_id;
    }

    public void setDashboard_id(Integer dashboard_id) {
        this.dashboard_id = dashboard_id;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public String getStatistics() {
        return statistics;
    }

    public void setStatistics(String statistics) {
        this.statistics = statistics;
    }
}
