package com.uep.wap.service;

import com.uep.wap.dto.AnalyticalDashboardDTO;
import com.uep.wap.model.AnalyticalDashboard;
import com.uep.wap.repository.AnalyticalDashboardRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AnalyticalDashboardsService {

    @Autowired
    private AnalyticalDashboardRepository analyticalDashboardRepository;

    public void addAnalyticalDashboard(AnalyticalDashboardDTO analyticalDashboardDTO) {
        AnalyticalDashboard analyticalDashboard = new AnalyticalDashboard();
        analyticalDashboard.setDashboard_id(analyticalDashboardDTO.getDashboard_id());
        analyticalDashboard.setRole(analyticalDashboardDTO.getRole());
        analyticalDashboard.setStatistics(analyticalDashboardDTO.getStatistics());
        analyticalDashboard.setUser(analyticalDashboardDTO.getUser());
        analyticalDashboardRepository.save(analyticalDashboard);
        System.out.println("AnalyticalDashboards added!");
    }

    public Iterable<AnalyticalDashboard> getAllAnalyticalDashboards() {
        return analyticalDashboardRepository.findAll();
    }

}




