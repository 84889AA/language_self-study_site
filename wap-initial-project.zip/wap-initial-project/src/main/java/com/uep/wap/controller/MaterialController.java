package com.uep.wap.controller;

import com.uep.wap.dto.MaterialDTO;
import com.uep.wap.model.Material;
import com.uep.wap.service.MaterialsService;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping(path = "/api")
public class MaterialController {

    private final MaterialsService materialsService;

    public MaterialController(MaterialsService materialsService) {
        this.materialsService = materialsService;
    }

    @GetMapping(path = "/allmaterials")
    public Iterable<Material> getAllMaterials(){
        return materialsService.getAllMaterials();
    }

    @PostMapping(path = "/allmaterials")
    public String addMaterials(@RequestBody MaterialDTO materialDTO){
        materialsService.addMaterial(materialDTO);
        return "Materials added!";
    }

}
