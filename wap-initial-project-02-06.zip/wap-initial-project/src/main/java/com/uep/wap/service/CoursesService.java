package com.uep.wap.service;

import com.uep.wap.model.Course;
import com.uep.wap.repository.CourseRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CoursesService {

    @Autowired
    private CourseRepository courseRepository;

    public Course saveDetails(Course course){
        return courseRepository.save(course);
    }

    public List<Course> getAllDetails(){
        return courseRepository.findAll();
    }

    public Course getDetailsById(int courseId){
        return courseRepository.findById(courseId).orElse(null);
    }

    public Course updateDetails(Course course){
        Course updateCourse = courseRepository.findById(course.getCourseId()).orElse(null);
        if(updateCourse != null){
            updateCourse.setName(course.getName());
            updateCourse.setTopic(course.getTopic());
            updateCourse.setUser(course.getUser());
            updateCourse.setLanguage(course.getLanguage());
            courseRepository.save(updateCourse);
            return updateCourse;
        }
        return null;
    }

    public String deleteCourse(int courseId){
        if(courseRepository.existsById(courseId)){
            courseRepository.deleteById(courseId);
            return "deleted"+courseId;
        }else{
            return "not found";
        }
    }
}




