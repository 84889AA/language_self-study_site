package com.uep.wap.controller;

import com.uep.wap.model.Material;
import com.uep.wap.service.MaterialsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class MaterialController {

    @Autowired
    private MaterialsService materialsService;

    @PostMapping(path = "/addMaterial")
    public Material postDetailsMaterial(@RequestBody Material material){
        return materialsService.saveDetails(material);
    }

    @GetMapping(path="/getMaterials")
    public List<Material> getDetailsMaterials(){
        return materialsService.getAllDetails();
    }

    @GetMapping("/getMaterialById/{materialId}")
    public Material getDetailsMaterialById(@PathVariable int materialId){
        return materialsService.getDetailsById(materialId);
    }

    @PutMapping("/updateMaterial")
    public Material updateDetailsMaterial(@RequestBody Material material){
        return materialsService.updateDetails(material);
    }

    @DeleteMapping("/deleteMaterial/{materialId}")
    public String deleteMaterial(@PathVariable int materialId){
        return materialsService.deleteMaterial(materialId);
    }
}
