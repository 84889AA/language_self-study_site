package com.uep.wap.service;

import com.uep.wap.model.AnalyticalDashboard;
import com.uep.wap.repository.AnalyticalDashboardRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AnalyticalDashboardsService {

    @Autowired
    private AnalyticalDashboardRepository analyticalDashboardRepository;

    //zapisuje 1 json do tabelki
    public AnalyticalDashboard saveDetails(AnalyticalDashboard analyticalDashboard){
        return analyticalDashboardRepository.save(analyticalDashboard);
    }

    //pobieranie wszystkich rekordow z bazy danych
    public List<AnalyticalDashboard> getAllDetails(){
        return analyticalDashboardRepository.findAll();
    }

    // pobieranie danych po ID
    public AnalyticalDashboard getDetailsById(int dashboard_id){
        return analyticalDashboardRepository.findById(dashboard_id).orElse(null);
    }

    //update po id, w postmanie trzeba np. dashboard_id:1
    public AnalyticalDashboard updateDetails(AnalyticalDashboard analyticalDashboard){
       AnalyticalDashboard updateAnalyticalDashboard = analyticalDashboardRepository.findById(analyticalDashboard.getDashboard_id()).orElse(null);
    if(updateAnalyticalDashboard != null){
        updateAnalyticalDashboard.setRole(analyticalDashboard.getRole());
        updateAnalyticalDashboard.setStatistics(analyticalDashboard.getStatistics());
        updateAnalyticalDashboard.setUser(analyticalDashboard.getUser());
        analyticalDashboardRepository.save(updateAnalyticalDashboard);
        return updateAnalyticalDashboard;
    }
    return null;
    }

    //usuwanie rekordu
    public String deleteAnalyticalDashboard(int dashboard_id){
        if(analyticalDashboardRepository.existsById(dashboard_id)){
            analyticalDashboardRepository.deleteById(dashboard_id);
            return "deleted "+dashboard_id;
        }else{
            return "not found";
        }
    }
}




