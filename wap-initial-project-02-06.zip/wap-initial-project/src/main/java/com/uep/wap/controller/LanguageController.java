package com.uep.wap.controller;

import com.uep.wap.model.Language;
import com.uep.wap.service.LanguagesService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class LanguageController {

    @Autowired
    private LanguagesService languagesService;

    @PostMapping(path = "/addLanguage")
    public Language postDetailsLanguage(@RequestBody Language language){
        return languagesService.saveDetails((language));
    }

    @GetMapping(path="/getLanguages")
    public List<Language> getDetailsLanguages(){
        return languagesService.getAllDetails();
    }

    @GetMapping("/getLanguageByName/{languageName}")
    public Language getDetailsLanguageByName(@PathVariable String languageName){
        return languagesService.getDetailsByName(languageName);
    }

    @PutMapping("/updateLanguage")
    public Language updateDetailsLanguage(@RequestBody Language language){
        return languagesService.updateDetails(language);
    }

    @DeleteMapping("/deleteLanguage/{languageName}")
    public String deleteLanguage(@PathVariable String languageName){
        return languagesService.deleteLanguage(languageName);
    }

}
