package com.uep.wap.controller;

import com.uep.wap.model.Course;
import com.uep.wap.service.CoursesService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class CourseController {

    @Autowired
    private CoursesService coursesService;

    @PostMapping(path = "/addCourse")
    public Course postDetailsCourse(@RequestBody Course course){
        return coursesService.saveDetails(course);
    }

    @GetMapping(path="/getCourses")
    public List<Course> getDetailsCourses(){
        return coursesService.getAllDetails();
    }

    @GetMapping("/getCourseById/{courseId}")
    public Course getDetailsCourseById(@PathVariable int courseId){
        return coursesService.getDetailsById(courseId);
    }

    @PutMapping("/updateCourse")
    public Course updateDetailsCourse(@RequestBody Course course){
        return coursesService.updateDetails(course);
    }

    @DeleteMapping("/deleteCourse/{courseId}")
    public String deleteCourse(@PathVariable int courseId){
        return coursesService.deleteCourse(courseId);
    }
}