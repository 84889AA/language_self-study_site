package com.uep.wap.service;

import com.uep.wap.model.Material;
import com.uep.wap.repository.MaterialRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MaterialsService {

    @Autowired
    private MaterialRepository materialRepository;

    public Material saveDetails(Material material){
        return materialRepository.save(material);
    }

    public List<Material> getAllDetails(){
        return materialRepository.findAll();
    }

    public Material getDetailsById(int materialId){
        return materialRepository.findById(materialId).orElse(null);
    }

    public Material updateDetails(Material material){
        Material updateMaterial = materialRepository.findById(material.getMaterialId()).orElse(null);
        if(updateMaterial != null){
            updateMaterial.setRole(material.getRole());
            updateMaterial.setUser(material.getUser());
            updateMaterial.setCourse(material.getCourse());
            materialRepository.save(updateMaterial);
            return updateMaterial;
        }
        return null;
    }

    public String deleteMaterial(int materialId){
        if(materialRepository.existsById(materialId)){
            materialRepository.deleteById(materialId);
            return "deleted"+materialId;
        }else{
            return "not found";
        }
    }
}




