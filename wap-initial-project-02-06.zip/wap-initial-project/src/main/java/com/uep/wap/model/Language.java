package com.uep.wap.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.List;

@Entity
@Data
@Table(name="Language")
@NoArgsConstructor
@AllArgsConstructor
public class Language {

    @Id
    @Column(name="languageName")
    private String languageName;

    @OneToMany(mappedBy="language", cascade = CascadeType.ALL)
    private List<LevelOfAdvancement> level_of_advancement;

    @ManyToOne
    @JoinColumn(name = "fk_user_id",referencedColumnName = "userId")
    private User user;


}


