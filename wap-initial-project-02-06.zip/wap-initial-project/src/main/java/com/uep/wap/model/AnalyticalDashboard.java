package com.uep.wap.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Entity
@Data
@Table(name="AnalyticalDashboard")
@NoArgsConstructor
@AllArgsConstructor

public class AnalyticalDashboard {

    @Id
    @Column(name = "Dashboard_id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer dashboard_id;

    @Column(name="role")
    private String role;

    @Column(name="statistics")
    private String statistics;

    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "fk_userId", referencedColumnName = "userId")
    private User user;
}

