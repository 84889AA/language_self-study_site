package com.uep.wap.controller;

import com.uep.wap.dto.AnalyticalDashboardDTO;
import com.uep.wap.dto.AnalyticalDashboardsDataDTO;
import com.uep.wap.model.AnalyticalDashboard;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping(path = "/api")
public class AnalyticalDashboardController {

    private final AnalyticalDashboardsService analyticalDashboardsService;

    public AnalyticalDashboardController(AnalyticalDashboardsService analyticalDashboardsService) {
        this.analyticalDashboardsService = analyticalDashboardsService;
    }

    @GetMapping(path = "/hello")
    public String sayHello(){
        return "Hello!";
    }

    @GetMapping(path = "/analyticalDashboards")
    public Iterable<AnalyticalDashboard> getAllAnalyticalDashboards(){
        return analyticalDashboardsService.getAllAnalyticalDashboards();
    }

    @PostMapping(path = "/analyticalDashboards")
    public String addAnalyticalDashboards(@RequestBody AnalyticalDashboardDTO analyticalDashboardDTO){
        analyticalDashboardsService.addAnalyticalDashboard(analyticalDashboardDTO);
        return "AnalyticalDashboards added!";
    }

}
