package com.uep.wap.model;

import javax.persistence.*;

@Entity
public class Language {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)

    private String name;

    @OneToOne
    @JoinColumn(name = "course_id")
    private Course course;

    @OneToMany(mappedBy = "language", cascade = CascadeType.ALL)
    private List<Level_of_advancement> level_of_advancement;

    @ManyToOne
    @JoinColumn(name = "user_id")
    private User user;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public com.uep.wap.service.Course getCourse() {
        return course;
    }

    public void setCourse(com.uep.wap.service.Course course) {
        this.course = course;
    }

    public List<Level_of_advancement> getLevel_of_advancement() {
        return level_of_advancement;
    }

    public void setLevel_of_advancement(List<Level_of_advancement> level_of_advancement) {
        this.level_of_advancement = level_of_advancement;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }
}


