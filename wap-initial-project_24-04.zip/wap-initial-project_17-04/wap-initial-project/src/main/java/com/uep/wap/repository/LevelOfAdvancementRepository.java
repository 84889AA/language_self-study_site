package com.uep.wap.repository;

import com.uep.wap.model.Level_of_advancement;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;


@Repository
public interface LevelOfAdvancementRepository extends CrudRepository<Level_of_advancement, Integer> {
}

