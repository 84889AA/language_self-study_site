package com.uep.wap.service;

import com.uep.wap.model.Material;
import com.uep.wap.repository.MaterialRepository;
import com.uep.wap.dto.MaterialDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MaterialsService {

    @Autowired
    private MaterialRepository materialRepository;

    public void addMaterial(MaterialDTO materialDTO) {
        Material material = new Material();
        material.setName(materialDTO.getName());
        material.setPoints(materialDTO.getPoints());
        materialRepository.save(material);
        System.out.println("Materials added!");
    }

    public Iterable<Material> getAllMaterials() {
        return materialRepository.findAll();
    }

}




