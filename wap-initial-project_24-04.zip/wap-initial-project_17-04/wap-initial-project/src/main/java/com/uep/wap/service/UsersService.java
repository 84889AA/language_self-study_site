package com.uep.wap.service;

import com.uep.wap.model.User;
import com.uep.wap.repository.UserRepository;
import com.uep.wap.dto.UserDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UsersService {

    @Autowired
    private UserRepository userRepository;

    public void addUser(UserDTO userDTO) {
        User user = new User();
        user.setName(userDTO.getName());
        user.setPoints(userDTO.getPoints());
        userRepository.save(user);
        System.out.println("Users added!");
    }

    public Iterable<User> getAllUsers() {
        return userRepository.findAll();
    }

}




