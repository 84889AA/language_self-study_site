package com.uep.wap.controller;

import com.uep.wap.model.AnalyticalDashboard;
import com.uep.wap.service.AnalyticalDashboardsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
//@RequestMapping(path = "/api")
public class AnalyticalDashboardController {

    @Autowired
    private AnalyticalDashboardsService analyticalDashboardsService;

    @PostMapping(path = "/addAnalyticalDashboard")
    public AnalyticalDashboard postDetailsAnalyticalDashboard(@RequestBody AnalyticalDashboard analyticalDashboard){
        return analyticalDashboardsService.saveDetails(analyticalDashboard);
    }

    @GetMapping(path="/getAnalyticalDashboards")
    public List<AnalyticalDashboard> getDetailsAnalyticalDashboards(){
        return analyticalDashboardsService.getAllDetails();
    }

    @GetMapping("/getAnalyticalDashboardById/{dashboard_id}")
    public AnalyticalDashboard getDetailsAnalyticalDashboardById(@PathVariable int dashboard_id){
        return analyticalDashboardsService.getDetailsById(dashboard_id);
    }

    @PutMapping("/updateAnalyticalDashboard")
    public AnalyticalDashboard updateDetailsAnalyticalDashboard(@RequestBody AnalyticalDashboard analyticalDashboard){
        return analyticalDashboardsService.updateDetails(analyticalDashboard);
    }

    @DeleteMapping("/deleteAnalyticalDashboard/{dashboard_id}")
    public String deleteAnalyticalDashboard(@PathVariable int dashboard_id){
        return analyticalDashboardsService.deleteAnalyticalDashboard(dashboard_id);
    }
}
