package com.uep.wap.service;

import com.uep.wap.model.Language;
import com.uep.wap.repository.LanguageRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class LanguagesService {

    @Autowired
    private LanguageRepository languageRepository;

    public Language saveDetails(Language language){
        return languageRepository.save(language);
    }

    public List<Language> getAllDetails(){
        return languageRepository.findAll();
    }

    public Language getDetailsByName(String languageName){
        return languageRepository.findById(languageName).orElse(null);
    }

    public Language updateDetails(Language language){
        Language updateLanguage = languageRepository.findById(language.getLanguageName()).orElse(null);
        if(updateLanguage != null){
            updateLanguage.setUser(language.getUser());
            languageRepository.save(updateLanguage);
            return updateLanguage;
        }
        return null;
    }

    public String deleteLanguage(String languageName){
        if(languageRepository.existsById(languageName)){
            languageRepository.deleteById(languageName);
            return "deleted"+languageName;
        }else{
            return "not found";
        }
    }
}




