package com.uep.wap.service;

import com.uep.wap.model.LevelOfAdvancement;
import com.uep.wap.repository.LevelOfAdvancementRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class LevelOfAdvancementsService {

    @Autowired
    private LevelOfAdvancementRepository levelOfAdvancementRepository;

    public LevelOfAdvancement saveDetails(LevelOfAdvancement levelOfAdvancement){
        return levelOfAdvancementRepository.save(levelOfAdvancement);
    }

    public List<LevelOfAdvancement> getAllDetails(){
        return levelOfAdvancementRepository.findAll();
    }

    public LevelOfAdvancement getDetailsByName(String nameOfLevel){
        return levelOfAdvancementRepository.findById(nameOfLevel).orElse(null);
    }

    public LevelOfAdvancement updateDetails(LevelOfAdvancement levelOfAdvancement){
        LevelOfAdvancement updateLevelOfAdvancement = levelOfAdvancementRepository.findById(levelOfAdvancement.getNameOfLevel()).orElse(null);
        if(updateLevelOfAdvancement != null){
            updateLevelOfAdvancement.setLanguage(levelOfAdvancement.getLanguage());
            levelOfAdvancementRepository.save(updateLevelOfAdvancement);
            return updateLevelOfAdvancement;
        }
        return null;
    }

    public String deleteLevelOfAdvancement(String nameOfLevel){
        if(levelOfAdvancementRepository.existsById(nameOfLevel)){
            levelOfAdvancementRepository.deleteById(nameOfLevel);
            return "deleted"+nameOfLevel;
        }else{
            return "not found";
        }
    }
}




