package com.uep.wap.controller;

import com.uep.wap.model.LevelOfAdvancement;
import com.uep.wap.service.LevelOfAdvancementsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
public class LevelOfAdvancementController {

    @Autowired
    private LevelOfAdvancementsService levelOfAdvancementsService;

    @PostMapping(path = "/addLevelOfAdvancement")
    public LevelOfAdvancement postDetailsLevelOfAdvancement(@RequestBody LevelOfAdvancement levelOfAdvancement){
        return levelOfAdvancementsService.saveDetails(levelOfAdvancement);
    }

    @GetMapping(path="/getLevelsOfAdvancement")
    public List<LevelOfAdvancement> getDetailsLevelsOfAdvancement(){
        return levelOfAdvancementsService.getAllDetails();
    }

    @GetMapping("/getLevelOfAdvancementByName/{nameOfLevel}")
    public LevelOfAdvancement getDetailsLevelOfAdvancementByName(@PathVariable String nameOfLevel){
        return levelOfAdvancementsService.getDetailsByName(nameOfLevel);
    }
    @PutMapping("/updateLevelOfAdvancement")
    public LevelOfAdvancement updateDetailsLevelOfAdvancement(@RequestBody LevelOfAdvancement levelOfAdvancement){
        return levelOfAdvancementsService.updateDetails(levelOfAdvancement);
    }

    @DeleteMapping("/deleteLevelOfAdvancement/{nameOfLevel}")
    public String deleteLevelOfAdvancement(@PathVariable String nameOfLevel){
        return levelOfAdvancementsService.deleteLevelOfAdvancement(nameOfLevel);
    }
}
