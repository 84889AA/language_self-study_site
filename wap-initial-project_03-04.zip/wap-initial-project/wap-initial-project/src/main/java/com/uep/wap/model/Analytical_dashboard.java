package com.uep.wap.model;

import javax.persistence.*;

@Entity
public class Analytical_dashboard {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)

    Private int dashboard_id;
    Private String role;
    Private object statistics;

    @ManyToOne
    @JoinColumn(name = "user_id")
    private User user;

    public int getDashboard_id() {
        return dashboard_id;
    }

    public void setDashboard_id(int dashboard_id) {
        this.dashboard_id = dashboard_id;
    }

    public Private getString() {
        return String;
    }

    public void setString(Private string) {
        String = string;
    }

    public Private getObject() {
        return object;
    }

    public void setObject(Private object) {
        this.object = object;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }
}



